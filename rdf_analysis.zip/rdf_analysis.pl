#!/usr/bin/perl
=b
This rdf analysis Perl script can only be conducted in Linux for the concurrent calculation of many rdf text files.
(developed by Prof. Shin-Pon Ju on 2021/Feb/20) 
=cut 

use strict;
use warnings;
use Cwd; #Find Current Path
use Parallel::ForkManager;
use MCE::Shared;
#use Data::Dumper

#my %hash = ('abc' => 123, 'def' => [4,5,6]);
#print Dumper(\%hash);

my $threads = `lscpu|grep "^CPU(s):" | sed 's/^CPU(s): *//g'`;
chomp $threads;
my $forkNo = $threads;
my $pm = Parallel::ForkManager->new("$forkNo");

my $specialPoints = 4;
# $specialPoints: the point number you want to get. first one is the rdf begin to have value beyond 0.0
# second one is the first peak, the third one is the minimun value between the first two peaks, the fourth one is the second peak. 

my $current_path = getcwd();# get the current path dir
chdir("$current_path/rcut");# cd to this dir for counting file number
my @files = <*.txt>;# only use to get the totoal number of files
chdir("$current_path");# return to original path

tie my @TP_data, 'MCE::Shared';# turning point data array
#print "TP_data: @TP_data\n";

for my $fid (0..$#files){
#for my $fid (0..0){# fid: rdf file ID
	$pm->start and next;
	#print "$_: rcut_$fid.txt\n";
	my $filename = "rcut_$fid.txt";	
	open my $ss,"< $current_path/rcut/$filename" or die "No $filename to open.\n $!";
	my @temp_array = <$ss>;
	close $ss; 
	#print "\@temp_array:@temp_array\n";
	my @temp_array1=grep (($_!~m{^\s*$|^#}),@temp_array); # remove blank lines
	my @rdf;
	for (@temp_array1){
		$_  =~ s/^\s+|\s+$//; #remove begining and tailing empty
		my @temp = split (/\s+/,$_) ;
		$temp[0]  =~ s/^\s+|\s+$//;
		chomp ($temp[0]);
		$temp[1]  =~ s/^\s+|\s+$//;
		chomp ($temp[1]);
		push @rdf,[$temp[0],$temp[1]];
	}
	
	my $TP_count = 0;
	my $firstTPID = -1;#get the distance ID for the first non-zero rdf value
	for my $did (@rdf){# did: rdf data ID
		$firstTPID++;
		#print "$did->[0],$did->[1]\n";
#the first turning point: begin non-zero value		
		if($TP_count == 0 and $did->[1] > 0){# rdf begins not zero
			$TP_count ++;
			push @{$TP_data[$fid]},[$did->[0],$did->[1]];
			last;
			#$TP_data[$fid]: an two-dimensional array reference 
			#print "distance:$TP_data[$fid]->[0]->[0],RDF:$TP_data[$fid]->[0]->[1]\n";
			#print "distance:${$TP_data[$fid]}[0][0],RDF:${$TP_data[$fid]}[0][1]\n";#dereference
		}
	}
	#print "firstTPID:$firstTPID\n";
	#die;
# find the rest turing points
	for my $id ($firstTPID..$#rdf-2){# did: rdf data ID from $firstTPID
		my $rdf0 = $rdf[$id][1];
		my $rdf1 = $rdf[$id+1][1];
		my $rdf2 = $rdf[$id+2][1];
		#print "$id:$rdf[$id][0],$rdf[$id][1]\n";
		#print "$id:$rdf[$id+1][0],$rdf[$id+1][1]\n";
		#print "$id:$rdf[$id+2][0],$rdf[$id+2][1]\n";
		if($TP_count == 1 and ($rdf0 < $rdf1 and $rdf2 < $rdf1) ){# the first peak
			$TP_count ++;
			push @{$TP_data[$fid]},[$rdf[$id+1][0],$rdf[$id+1][1]];
		#	print "distance:$TP_data[$fid]->[1]->[0],RDF:$TP_data[$fid]->[1]->[1]\n";
		#	print "distance:${$TP_data[$fid]}[1][0],RDF:${$TP_data[$fid]}[1][1]\n";#dereference
		#die;
		}
		elsif($TP_count == 2 and ($rdf0 > $rdf1 and $rdf2 > $rdf1) ){# the first minimum
			$TP_count ++;
			push @{$TP_data[$fid]},[$rdf[$id+1][0],$rdf[$id+1][1]];
			#print "TP_count:$TP_count\n";
			#print "rdf0-2: $rdf0,$rdf1,$rdf2\n";
			#print "distance:$TP_data[$fid]->[2]->[0],RDF:$TP_data[$fid]->[2]->[1]\n";
			#print "distance:${$TP_data[$fid]}[2][0],RDF:${$TP_data[$fid]}[2][1]\n";#dereference		
		}
		elsif($TP_count == 3 and ($rdf0 < $rdf1 and $rdf2 < $rdf1) ){# the second peak
			$TP_count ++;
			push @{$TP_data[$fid]},[$rdf[$id+1][0],$rdf[$id+1][1]];
			#print "TP_count:$TP_count\n";
			#print "rdf0-2: $rdf0,$rdf1,$rdf2\n";
			#print "distance:$TP_data[$fid]->[3]->[0],RDF:$TP_data[$fid]->[3]->[1]\n";
			#print "distance:${$TP_data[$fid]}[3][0],RDF:${$TP_data[$fid]}[3][1]\n";#dereference
			last;
		}
    }#second rdf loop
    
############################

	$pm->finish;
}#file loop
$pm->wait_all_children;

#output analysis result
open my $rdfout,">./rdf_analysis.dat";
print $rdfout "#distance and rdf values for 4 turning points\n\n";

for my $fid (0..$#files){
#for my $fid (0..0){
	
	print $rdfout "file_$fid: ";
	
	for my $TPid (0..$specialPoints-1){
		print $rdfout "${$TP_data[$fid]}[$TPid][0] ${$TP_data[$fid]}[$TPid][1] ";
	}
	print $rdfout "\n";
}
close($rdfout);
