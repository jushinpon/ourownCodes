#!/usr/bin/perl
use strict;
use warnings;
use Cwd; #Find Current Path
use Parallel::ForkManager;
use MCE::Shared;

use Data::Dumper

my %hash = ('abc' => 123, 'def' => [4,5,6]);
#print Dumper(\%hash);

die;
